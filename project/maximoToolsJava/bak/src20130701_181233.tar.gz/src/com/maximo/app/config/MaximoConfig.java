package com.maximo.app.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.util.JMXUtils;
import com.maximo.app.resources.MXServerConfig;

public class MaximoConfig {
	
	private DruidDataSource dataSource;
	private MXServerConfig mxsc;
	private static int initialSize = 10;
	private static int minPoolSize = 15;
	private static int maxPoolSize = 30;
	private static int maxActive = 25;

	public MaximoConfig() {
		// TODO Auto-generated constructor stub
		mxsc=new MXServerConfig();
		mxsc.setServer("172.22.48.70:13481/MXServer");
		mxsc.setServer("172.22.48.70:13473/MXServer");
		mxsc.setServer("172.22.48.100:13400/MXServer");
//		mxsc.setServer("172.22.48.101:13471/MXServer");
		mxsc.setUsername("maxadmin");
		mxsc.setPassword("maxadmin");
		dataSource = new DruidDataSource();
		String jdbcUrl = "jdbc:oracle:thin:@172.22.48.70:1521:orcl";
		String user = "maximodemo";
		String password = "maximo";
		String driverClass = "oracle.jdbc.driver.OracleDriver";
		JMXUtils.register("com.alibaba:type=DruidDataSource", dataSource);
		
		jdbcUrl = "jdbc:oracle:thin:@172.22.48.70:1521:crep";
		user = "maximo";
		password = "maximo";
//		jdbcUrl = "jdbc:oracle:thin:@172.22.48.254:1522:eamcrpjs";
//		user = "maxdb";
//		password = "maximo";
//		jdbcUrl = "jdbc:oracle:thin:@172.22.48.101:1521:orcl";
//		user = "maximo7001";
//		password = "maximo";
		dataSource.setInitialSize(initialSize);
		dataSource.setMaxActive(maxActive);
		dataSource.setMinIdle(minPoolSize);
		dataSource.setMaxIdle(maxPoolSize);
		dataSource.setPoolPreparedStatements(true);
		dataSource.setDriverClassName(driverClass);
		dataSource.setUrl(jdbcUrl);
		dataSource.setPoolPreparedStatements(true);
		dataSource.setUsername(user);
		dataSource.setPassword(password);
		dataSource.setValidationQuery("SELECT 'asus' from dual");
		dataSource.setTestOnBorrow(true);

	}
	
	public MXServerConfig getMXServerConfig(){
		return mxsc;
	}
			
	public DruidDataSource getDruidDataSource(){
		return dataSource;
	}

}
