package com.maximo.tools.impxml.task;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.maximo.app.MTException;
import com.shoukaiseki.sql.oracle.OracleSqlDetabese;

public class PreparedStatementSet extends Task{
	public static final String NAME="NAME";
	private OracleSqlDetabese osd=null;
	private PreparedStatement ps=null;
	
	public PreparedStatementSet() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	@Override
	public void parseElement() throws MTException {
		// TODO Auto-generated method stub
		super.parseElement();
		osd=new OracleSqlDetabese(con);
		osd.setSql(cdata);
		try {
			ps = osd.prepareStatement();
			om.info("PreparedStatementSet: ["+getName()+"]{"+cdata+"}已初始化");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MTException(getName()+":"+getCdata()+"初始化失败:",e);
		}
	}
	
	public String getName(){
		 return getProperty(NAME);
	}
	
	public OracleSqlDetabese getOracleSqlDetabese(){
		return osd;
	}
	
	public PreparedStatement getPreparedStatement(){
		return ps;
	}
	
	public void executeBatch() throws MTException{
		try {
			ps.executeBatch();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MTException(e);
		}
	}

}
