package com.maximo.tools.impxml.task;

import java.sql.Types;

import com.maximo.app.MTException;

public class Column extends Task{
	public final static String NAME="NAME" ;
	/**
	 * 最開始的值
	 */
	private String beginValue="";
	/**
	 * 字段的值
	 */
//	private Object value=null;
	/**
	 * 插入字段採用的類型
	 */
	private Types type=null;
	public Column(){
		
	}
	
	public Column(String cellName){
		propertys.put(NAME, IXFormat.trimUpperCase(cellName));
	}
	
	public String getName() {
		return propertys.get(NAME).toUpperCase();
	}


	public String getValue() {
		return cdata.toString();
	}

	public void setValue(String value) {
		this.cdata = IXFormat.transColumnValue(value);
	}

	public Types getType() {
		return type;
	}

	public void setType(Types type) {
		this.type = type;
	}
	
	public boolean isNull(){
		return IXFormat.isNullOrTrimEmpty(cdata);
	}
	
	@Override
	public void parseElement() throws MTException {
		// TODO Auto-generated method stub
		super.parseElement();
		setValue(cdata);
		setBeginValue(cdata);
		om.debug(getName()+":"+getValue());
	}
	
	@Override
	public String[] getFormatTrimUpperCaseProperty() {
		// TODO Auto-generated method stub
		return new String[]{NAME};
	}
	
	@Override
	public boolean hasNextKoElement() {
		// TODO Auto-generated method stub
		return false;
	}

	/** 最開始的值
	 * @return
	 */
	public String getBeginValue() {
		return beginValue;
	}

	private void setBeginValue(String beginValue) {
		this.beginValue = beginValue;
	}

	public boolean isBeginNull() {
		// TODO Auto-generated method stub
		return IXFormat.isNullOrTrimEmpty(beginValue);
	}

}
