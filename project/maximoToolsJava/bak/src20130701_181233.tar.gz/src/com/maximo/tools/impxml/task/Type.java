package com.maximo.tools.impxml.task;

public class Type {

}
